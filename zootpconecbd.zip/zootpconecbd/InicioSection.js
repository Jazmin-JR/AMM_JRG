import React from 'react';
import { View, ImageBackground, StyleSheet, Image, TouchableOpacity, Text } from 'react-native';

const backgroundImage = require('./assets/Rectangle.png');
const logoImage = require('./assets/image.png');

const InicioSectionScreen = ({ navigation }) => {
  const handleSignUp = () => {
    navigation.navigate('Signup');
  };

  const handleLogin = () => {
    navigation.navigate('Login');
  };

  return (
    <View style={styles.container}>
      <ImageBackground source={backgroundImage} style={styles.image}>
        <View style={styles.formContainer}>
          <Image source={logoImage} style={styles.logo} />
          <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.loginButton} onPress={handleSignUp}>
            <Text style={styles.buttonText}>Registrarse</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  formContainer: {
    padding: 20,
    alignItems: 'center',
  },
  logo: {
    position: 'cover',
    width: 150,
    height: 120,
    right: 2,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  loginButton: {
    backgroundColor: '#496C6A',
    padding: 10,
    borderRadius: 19,
    alignItems: 'center',
    width: '80%',
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  
});

export default InicioSectionScreen;