import React from 'react';
import Navigation from './AppNavigation'; 

const App = () => {
  return <Navigation />;
};

export default App;  