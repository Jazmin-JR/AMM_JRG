import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import LoginScreen from './Login';
import SignupScreen from './Signup';
import PaginaInicioScreen from './PaginaInicio';
import InicioSectionScreen from './InicioSection';
import BarraNavegacionScreen from './BarraNavegacin';

const Stack = createStackNavigator();

const AppNavigation = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="InicioSection">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Signup" component={SignupScreen} />
        <Stack.Screen name="PaginaInicio" component={PaginaInicioScreen} />
        <Stack.Screen name="InicioSection" component={InicioSectionScreen} />
        <Stack.Screen name="BarraNavegacion" component={BarraNavegacionScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigation;