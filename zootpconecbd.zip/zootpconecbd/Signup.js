import React, { useState } from 'react';
import { View, ImageBackground, StyleSheet, Image, TouchableOpacity, Text, TextInput } from 'react-native';

const backgroundImage = require('./assets/Rectangle.png');
const logoImage = require('./assets/image.png');

const SignupScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');

  const handleSignUp = () => {
    // Lógica de registro con los datos ingresados
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Password:', password);
    console.log('Phone:', phone);

    // Envía los datos a un servidor
    fetch('http://localhost:3000/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: name,
        email: email,
        password: password,
        phone: phone,
      }),
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        // Navega a la página principal después del registro exitoso
        navigation.navigate('PaginaInicio', { userName: name });
      })
      .catch(error => {
        console.error('Error:', error);
        // Maneja el error aquí
      });
  };
  return (
    <View style={styles.container}>
      <ImageBackground source={backgroundImage} style={styles.image}>
        <View style={styles.formContainer}>
          {/* Logo */}
          <Image source={logoImage} style={styles.logo} />

          {/* Título debajo del logo */}
          <Text style={styles.title}>Sign Up</Text>

          {/* Input de Name */}
          <Text style={styles.labelText}>Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Your Name"
            placeholderTextColor="#000"
            value={name}
            onChangeText={(text) => setName(text)}
          />

          {/* Input de Email */}
          <Text style={styles.labelText}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Email@gmail.com"
            placeholderTextColor="#000"
            value={email}
            onChangeText={(text) => setEmail(text)}
          />

          {/* Input de Contraseña */}
          <Text style={styles.labelText}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#000"
            secureTextEntry
            value={password}
            onChangeText={(text) => setPassword(text)}
          />

          {/* Input de Teléfono */}
          <Text style={styles.labelText}>Phone</Text>
          <TextInput
            style={styles.input}
            placeholder="Phone"
            placeholderTextColor="#000"
            value={phone}
            onChangeText={(text) => setPhone(text)}
          />

          {/* Botón de Registrarse */}
          <TouchableOpacity style={styles.signupButton} onPress={handleSignUp}>
            <Text style={styles.buttonText}>Sign Up</Text>
          </TouchableOpacity>

          <Text></Text>
          
          <TouchableOpacity style={styles.linkText} onPress={handleLogin}>
            <Text style={styles.linkText}>Log In</Text>
          </TouchableOpacity>
         
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1,
  },
  image: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  formContainer: {
    padding: 20,
    alignItems: 'center',
  },
  logo: {
    width: 150,
    height: 120,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#aa',
    marginBottom: 20,
  },
  labelText: {
    fontSize: 10,
    color: '#000',
    marginBottom: 5,
    alignSelf: 'flex-start',
    paddingLeft: 40,
  },
  input: {
    height: 40,
    width: '80%',
    borderColor: '#ccc',
    backgroundColor: '#ccc',
    borderWidth: 3,
    marginBottom: 20,
    paddingLeft: 20,
    color: '#000',
  },
  signupButton: {
    backgroundColor: '#496C6A',
    padding: 10,
    borderRadius: 19,
    alignItems: 'center',
    width: '80%',
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  linkText: {
    color: '#cc',
    textDecorationLine: 'underline',
    marginTop: 10,
  },
});

export default SignupScreen;
