import React from 'react';
import { ImageBackground, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native'; // Importa el hook de navegación

const backgroundImage = require('./assets/Rectangle.png');
const overlayImage = require('./assets/2.jpg');
const logoImage = require('./assets/image.png');

const PaginaInicioScreen = () => {
  const navigation = useNavigation(); // Inicializa el hook de navegación

  const handelBarraNavegacionScreen = () => {
    // Navegar a la otra página cuando se hace clic en el botón
    navigation.navigate('BarraNavegacion'); // Reemplaza 'OtraPagina' con el nombre de tu otra pantalla
  };
  return (
    <View style={styles.container}>
      <ImageBackground source={backgroundImage} style={styles.imageBackground}>
        <View style={styles.overlayContainer}>
          {/* Imagen de fondo */}
          <Image source={overlayImage} style={styles.overlayImage} />

          {/* Logo como botón en la esquina inferior derecha */}
          <TouchableOpacity style={styles.logoContainer} onPress={handelBarraNavegacionScreen}>
            <Image source={logoImage} style={styles.logo} />
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  imageBackground: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  overlayContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlayImage: {
    resizeMode: 'contain',
    width: '120%', // Ajusta según tus necesidades para expandir horizontalmente
    height: '80%',  // Ajusta según tus necesidades
  },
  logoContainer: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    backgroundColor: '#ffff',
    borderRadius: 50,
    padding: 8,
  },
  logo: {
    width: 85,
    height: 85,
    resizeMode: 'contain',
  },
});

export default PaginaInicioScreen;
