import React, { useState } from 'react';
import { View, ImageBackground, StyleSheet, Image, TouchableOpacity, Text, TextInput } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
const backgroundImage = require('./assets/Rectangle.png');
const logoImage = require('./assets/image.png');

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const userCredential = await auth().signInWithEmailAndPassword(email, password);
      console.log('User signed in successfully!', userCredential.user);
      // Navigate to the main page or any other screen after successful login
      navigation.navigate('PaginaInicio');
    } catch (error) {
      console.error('Error signing in:', error.message);
      // Handle login error, e.g., display an error message to the user
    }
  };

  const handleSignUp = () => {
    // Navigate to the signup page
    navigation.navigate('Signup');
  };
  
  return (
    <View style={styles.container}>
      <ImageBackground source={backgroundImage} style={styles.image}>
        <View style={styles.formContainer}>
          {/* Logo */}
          <Image source={logoImage} style={styles.logo} />
          {/* Título debajo del logo */}
          <Text style={styles.title}>Log In</Text>

          {/* Input de Email */}
          <Text style={styles.labelText}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Email@gmail.com"
            placeholderTextColor="#000"
            value={email}
            onChangeText={(text) => setEmail(text)}
          />

          {/* Input de Contraseña */}
          <Text style={styles.labelText}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#000"
            secureTextEntry
            value={password}
            onChangeText={(text) => setPassword(text)}
          />

          {/* Botón de Iniciar Sesión */}
          <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>

          <Text></Text><Text></Text>
          <Text style={styles.linkText}>¿Olvidaste tu contraseña?</Text>

          <TouchableOpacity style={styles.linkText} onPress={handleSignUp}>
            <Text style={styles.linkText}>Registrarse</Text>
          </TouchableOpacity>

          <Text></Text><Text></Text>
          <TouchableOpacity
            onPress={() => {
              // handle onPress
            }}>
            <View style={styles.btnSecondary}>
              <MaterialCommunityIcons
                color="#000"
                name="google"
                size={22}
                marginLeft={17}
                style={{ marginRight: 10 }}
              />
              <Text style={styles.btnSecondaryText}>Google</Text>
              <View style={{ width: 30 }} />
            </View> 
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  formContainer: {
    padding: 20,
    alignItems: 'center',
  },
  logo: {
    width: 150,
    height: 120,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#aa',
    marginBottom: 20,
  },
  labelText: {
    fontSize: 10,
    color: '#000',
    marginBottom: 5,
    alignSelf: 'flex-start',
    paddingLeft: 40,
  },
  input: {
    height: 40,
    width: '80%',
    borderColor: '#ccc',
    backgroundColor: '#ccc',
    borderWidth: 3,
    marginBottom: 20,
    paddingLeft: 20,
    color: '#000',
  },
  loginButton: {
    backgroundColor: '#496C6A',
    padding: 10,
    borderRadius: 19,
    alignItems: 'center',
    width: '80%',
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  linkText: {
    color: '#cc',
    textDecorationLine: 'underline',
    marginTop: 10,
  },
  btnSecondary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderWidth: 1,
    backgroundColor: 'transparent',
    borderColor: '#000',
    marginBottom: 12,
  }, 
  btnSecondaryText: {
    fontSize: 18,
    lineHeight: 26,
    fontWeight: '600',
    color: '#000',
    marginLeft: 8, // Added margin to separate icon and text
  },
});

export default LoginScreen;
