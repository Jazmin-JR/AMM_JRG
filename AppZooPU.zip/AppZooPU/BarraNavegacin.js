import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground, Image, SafeAreaView, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const backgroundImage = require('./assets/Rectangle.png');

const items = [
  {
    img: 'https://www.zoomadrid.com/content/dam/zoo/images/animals/panda-gigante/Oso-panda-gigante-Zoo-Madrid-main.jpg',
    title: 'Panda                            Haliaeetus albicilla',
    author: 'JRG',
    tag: 'Mamifero',
  },

  {
    img: 'https://www.zoomadrid.com/content/dam/zoo/images/animals/gacela-dorcas/Gacela-dorcas-Zoo-Madrid-main.jpg',
    title: 'Gacela Dorcas                Gazella Dorcas Neglecta',
    author: 'John Smith',
    authorImg:
      'https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=2.5&w=256&h=256&q=80',
    tag: 'Mamifero',
    },

  {
    img: 'https://www.zoomadrid.com/content/dam/zoo/images/animals/pigargo-europeo/Pigargo-europeo-Zoo-Madrid-main.jpg',
    title: 'Pagargo europeo             Haliaeetus albicilla',
    author: 'Emily Chen',
    authorImg:
      'https://images.unsplash.com/photo-1515621061946-eff1c2a352bd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1389&q=80',
    tag: 'Aves',
    date: 'Mar 22, 2023',
  },
  
  {
    img: 'https://www.zoomadrid.com/content/dam/zoo/images/animals/tortuga-carey/Tortuga-carey-Zoo-Madrid-2.jpg',
    title: "Tortuga carey    Eretmochelys imbricata",
    author: 'Samantha Lee',
    authorImg:
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=2.5&w=256&h=256&q=80',
    tag: 'Reptiles',
    date: 'Mar 21, 2023',
  },

  {
    img: 'https://www.zoomadrid.com/content/dam/zoo/images/animals/elefante-asiatico/Elefante-asiatico-Zoo-Madrid-main.jpg',
    title: 'Elefante asiático            Elephas maximus',
    author: 'John Smith',
    authorImg:
      'https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=2.5&w=256&h=256&q=80',
      tag: 'Mamifero',
      date: 'Mar 20, 2023',
  },
  {
    img: 'https://www.zoomadrid.com/content/dam/zoo/images/animals/tiburon-gris/Tiburon-gris-Zoo-Madrid-main.jpg',
    title: 'Tiburón gris              Carcharhinus plumbeus',
    author: 'Emily Chen',
    authorImg:
      'https://images.unsplash.com/photo-1515621061946-eff1c2a352bd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1389&q=80',
    tag: 'Peces',
    date: 'Mar 19, 2023',
  },
];

const AnimalsScreen = () => (
  <View style={{ flex: 1, padding: 16 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 16 }}>Animals</Text>
    <ScrollView>
      {items.map(({ img, title, author, authorImg, tag, date }, index) => (
        <TouchableOpacity
          key={index}
          onPress={() => {
            // handle onPress
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 16,
              backgroundColor: '#fff',
              borderRadius: 12,
              overflow: 'hidden',
              elevation: 2, // Optional: Adds shadow on Android
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.2,
              shadowRadius: 2,
            }}>
            <Image
              alt=""
              resizeMode="cover"
              source={{ uri: img }}
              style={{ width: 96, height: 96, borderRadius: 12 }}
            />

            <View style={{ flex: 1, padding: 16 }}>
              <Text style={{ fontWeight: '500', fontSize: 12, color: '#939393', textTransform: 'capitalize', marginBottom: 7 }}>
                {tag}
              </Text>

              <Text style={{ fontWeight: '600', fontSize: 16, lineHeight: 19, color: '#000', marginBottom: 8 }}>
                {title}
              </Text>

              <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: -8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, borderRightWidth: 1, borderColor: 'transparent' }}>
                  <Image alt="" source={{ uri: authorImg }} style={{ width: 22, height: 22, borderRadius: 9999, marginRight: 6 }} />
                  <Text style={{ fontWeight: '400', fontSize: 13, color: '#939393' }}>{author}</Text>
                </View>

                <Text style={{ fontSize: 17, fontWeight: 'bold', color: '#939393', marginHorizontal: 8 }}>·</Text>

                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, borderRightWidth: 1, borderColor: 'transparent' }}>
                  <Text style={{ fontWeight: '400', fontSize: 13, color: '#939393' }}>{date}</Text>
                </View>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      ))}
    </ScrollView>
  </View>
);





const items2 = [
  {
    img: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/17/f8/fe/a2/iconoce-a-mas-de-10-000.jpg?w=1200&h=-1&s=1',
    title: 'Acuario                                Adentres en las profundidades del fascinante mundo marino ',
    author: 'Samantha Lee',
    authorImg:
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=2.5&w=256&h=256&q=80',
    tag: 'Acuario Marino',
    date: 'Mar 24, 2023',
  },
  {
    img: 'https://tanzaniaspecialist.es/wp-content/uploads/sites/13/2020/08/masai-mara-cheetah-800x490.jpg',
    title: 'Safari Masai Mara                    Zoo te invita a sus visitantes a que “descubran África” en el Safari Masai Mara',
    author: 'John Smith',
    authorImg:
      'https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=2.5&w=256&h=256&q=80',
    tag: 'Safari',
    date: 'Mar 23, 2023',
  },
  {
    img: 'https://zooguadalajara.com.mx/uploads/atraccion/3/IMG_5293.jpg',
    title: 'Sky Zoo                                     Sky Zoo es la nueva forma de ver el zoológico, ahora desde las alturas ',
    author: 'Emily Chen',
    authorImg:
      'https://images.unsplash.com/photo-1515621061946-eff1c2a352bd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1389&q=80',
    tag: 'Sky',
    date: 'Mar 22, 2023',
  },
  {
    img: 'https://cdn.milenio.com/uploads/media/2015/07/18/pinguinos-en-el-zoologico-guadalajara.jpeg',
    title: "Antartida                                             Los pingüinos Adelie o Adelia, reciben su nombre en honor a la esposa del explorador francés Dumont D’Urville que los descubrió en la Antártida en 1830.",
    author: 'Samantha Lee',
    authorImg:
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=2.5&w=256&h=256&q=80',
    tag: 'Antartida',
    date: 'Mar 21, 2023',
  },
  

];

const AttractionsScreen = () => (
  <View style={{ flex: 1, padding: 16 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 16 }}>Animals</Text>
    <ScrollView>
      {items2.map(({ img, title, author, authorImg, tag, date }, index) => (
        <TouchableOpacity
          key={index}
          onPress={() => {
            // handle onPress
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 16,
              backgroundColor: '#fff',
              borderRadius: 12,
              overflow: 'hidden',
              elevation: 2, // Optional: Adds shadow on Android
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.2,
              shadowRadius: 2,
            }}>
            <Image
              alt=""
              resizeMode="cover"
              source={{ uri: img }}
              style={{ width: 96, height: 96, borderRadius: 12 }}
            />

            <View style={{ flex: 1, padding: 16 }}>
              <Text style={{ fontWeight: '500', fontSize: 12, color: '#939393', textTransform: 'capitalize', marginBottom: 7 }}>
                {tag}
              </Text>

              <Text style={{ fontWeight: '600', fontSize: 16, lineHeight: 19, color: '#000', marginBottom: 8 }}>
                {title}
              </Text>

              <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: -8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, borderRightWidth: 1, borderColor: 'transparent' }}>
                  <Image alt="" source={{ uri: authorImg }} style={{ width: 22, height: 22, borderRadius: 9999, marginRight: 6 }} />
                  <Text style={{ fontWeight: '400', fontSize: 13, color: '#939393' }}>{author}</Text>
                </View>

                <Text style={{ fontSize: 17, fontWeight: 'bold', color: '#939393', marginHorizontal: 8 }}>·</Text>

                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, borderRightWidth: 1, borderColor: 'transparent' }}>
                  <Text style={{ fontWeight: '400', fontSize: 13, color: '#939393' }}>{date}</Text>
                </View>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      ))}
    </ScrollView>
  </View>
);

const BarraNavegacionScreen = () => {
  const navigation = useNavigation();
  const [selectedTab, setSelectedTab] = React.useState('Animals');

  const handleNavigation = (screenName) => {
    navigation.navigate(screenName);
    setSelectedTab(screenName);
  };

  return (
    <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
      <View style={styles.container}>
        {/* Barra superior dividida en dos secciones */}
        <View style={styles.barContainer}>
          <TouchableOpacity
            onPress={() => handleNavigation('Animals')}
            style={[
              styles.tabButton,
              selectedTab === 'Animals' && styles.selectedTab,
            ]}
          >
            <Text style={styles.barText}>Animals</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleNavigation('Attractions')}
            style={[
              styles.tabButton,
              selectedTab === 'Attractions' && styles.selectedTab,
            ]}
          >
            <Text style={styles.barText}>Atracciones</Text>
          </TouchableOpacity>
        </View>

        {/* Contenido de la pantalla adicional */}
        {selectedTab === 'Animals' ? (
          <AnimalsScreen />
        ) : selectedTab === 'Attractions' ? (
          <AttractionsScreen />
        ) : null}
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    padding: 16,
  },
  barContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    backgroundColor: '#ffff',
  },
  selectedTab: {
    borderBottomWidth: 2,
    borderBottomColor: 'green', // Puedes cambiar este color
  },
  barText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'green', // Cambia el color del texto según tu necesidad
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default BarraNavegacionScreen;
